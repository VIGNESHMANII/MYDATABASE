package com.SpringBootApp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.SpringBootApp.entity.Employee;
import com.SpringBootApp.repo.EmployeeRepo;

@Controller
public class EmpController {
	@Autowired
	EmployeeRepo er;

	@GetMapping("/")
	public String getAll(Model m)
	{
		List<Employee>  empAll = er.ShowAll();
		m.addAttribute("empAll", empAll);
		return "ShowAllEmps";
	}

	
	@GetMapping("addemp")
	public String AddNewEmp(Model m)
	{
		return "AddEmp";
	}
	
	
	@PostMapping("addemprocess")
	public String AddNewEmp(@RequestParam String txtEname,
			@RequestParam String txtJob,
			@RequestParam String txtSal,
			@RequestParam String txtEmail,
			@RequestParam String txtPass, Model m)
	{
		
		Employee emp = new Employee();
		emp.setEname(txtEname);
		emp.setJob(txtJob);
		emp.setSal(Integer.parseInt(txtSal));
		emp.setEmail(txtEmail);
		emp.setPasword(txtPass);
		
		String res = er.AddEmployee(emp);
		m.addAttribute("msg", res);
		return "AddEmp";
	}
	
	@GetMapping("showall")
	public String DisplayAll(Model m)
	{
		List<Employee>  empAll = er.ShowAll();
		m.addAttribute("empAll", empAll);
		return "ShowAllEmps";
	}
	
	@GetMapping("search")
	public String SearchEmpInfo(Model m)
	{		
		return "SearchEmp";
	}
	
	@PostMapping("searchEmp")
	public String SearchEmpInfo(@RequestParam String txtEno, Model m)
	{		
		Employee emp = er.SearchEmp(Integer.parseInt(txtEno));
		if(emp!=null)
			m.addAttribute("emp", emp);
		else
			m.addAttribute("msg", "Employee Not Found");
		return "SearchEmp";
	}
	
}



