package com.SpringBootApp.repo;

import java.util.List;

import com.SpringBootApp.entity.Employee;

public interface EmployeeRepo {
	

		public String AddEmployee(Employee emp);
		public List<Employee> ShowAll();
		public Employee SearchEmp(int eno);

}
