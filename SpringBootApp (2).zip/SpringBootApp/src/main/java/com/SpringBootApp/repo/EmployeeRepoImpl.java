package com.SpringBootApp.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.SpringBootApp.entity.Employee;
@Component
public class EmployeeRepoImpl implements EmployeeRepo {

	@Autowired
	JdbcTemplate jt;
	
	@Override
	public String AddEmployee(Employee emp) {		
		String sql = "Insert into Emp(ename,job, sal, email, pasword) values(?,?,?,?,?)";
		int r = jt.update(sql, new Object[] {emp.getEname(), emp.getJob(), emp.getSal(), emp.getEmail(), emp.getPasword()});

		if(r>=1)
			return "Emp Added....";
		else
			return "Error....";
	}

	@Override
	public List<Employee> ShowAll() {
		String sql = "Select * from emp";
		List<Employee> lstAll = jt.query(sql, new BeanPropertyRowMapper(Employee.class));
		return lstAll;
	}

	@Override
	public Employee SearchEmp(int eno) {
		String sql = "Select * from emp where empno=?";
		Employee emp=null;
		try
		{
			emp = (Employee)jt.queryForObject(sql, new Object[] {eno}, new BeanPropertyRowMapper(Employee.class));
		}
		catch(Exception ex)
		{
			emp = null;
		}
		return emp;
	}

}
