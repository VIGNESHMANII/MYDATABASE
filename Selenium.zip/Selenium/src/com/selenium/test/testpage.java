package com.selenium.test;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class testpage {
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.edge.driver", "..//Selenium//msedgedriver.exe"); // value is path of the exe file
		WebDriver driver = new EdgeDriver();
		driver.get("http://localhost:9016/stdmarksmanage/ab");
		driver.findElement(By.name("username")).sendKeys("smmadmin");
		Thread.sleep(3000);
		driver.findElement(By.name("password")).sendKeys("smmadmin");
		Thread.sleep(3000);
		WebElement ddlTypeDropdown = driver.findElement(By.name("select"));
		Select typeoption = new Select(ddlTypeDropdown);
		typeoption.selectByValue("1");
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[type='submit']")).submit();
		Thread.sleep(3000);

		}
}
