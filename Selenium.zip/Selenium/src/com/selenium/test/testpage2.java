package com.selenium.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class testpage2 {
	public static void main(String[] args) throws Exception {
	System.setProperty("webdriver.edge.driver", "..//Selenium//msedgedriver.exe"); // value is path of the exe file
	WebDriver driver = new EdgeDriver();
	driver.get("http://localhost:9002/myjdbcapp/addemp");
	driver.findElement(By.name("txtEname")).sendKeys("suba");
	Thread.sleep(3000);
	driver.findElement(By.name("txtJob")).sendKeys("developer");
	Thread.sleep(3000);
	driver.findElement(By.name("txtSal")).sendKeys("30000");
	Thread.sleep(3000);
	driver.findElement(By.name("txtEmail")).sendKeys("suba@gmail.com");
	Thread.sleep(3000);
	driver.findElement(By.name("txtPass")).sendKeys("suba123");
	Thread.sleep(3000);
	driver.findElement(By.cssSelector("input[type='submit']")).submit();

}
}
