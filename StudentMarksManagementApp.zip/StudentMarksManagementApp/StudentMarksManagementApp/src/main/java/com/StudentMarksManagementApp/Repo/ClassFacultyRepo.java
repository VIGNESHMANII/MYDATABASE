package com.StudentMarksManagementApp.Repo;



import java.util.List;
import com.StudentMarksManagementApp.Entity.Class;
import com.StudentMarksManagementApp.Entity.ClassFaculty;
import com.StudentMarksManagementApp.Entity.Faculty;


/*import com.StudentMarksApp.Entity.ClassFaculty;
import com.StudentMarksApp.Entity.Classes;
import com.StudentMarksApp.Entity.Faculty;*/



public interface ClassFacultyRepo {

public List<Faculty> showFaculty();
public List<Class> showClass();
public String addClassFaculty(ClassFaculty cfo);
public List<ClassFaculty> showClassFaculty();



}








/*package com.StudentMarksManagementApp.Repo;

import java.util.List;

import com.StudentMarksManagementApp.Entity.Class;
import com.StudentMarksManagementApp.Entity.ClassFaculty;
import com.StudentMarksManagementApp.Entity.Faculty;

public interface ClassFacultyRepo {
	
	public String AddClassFaculty(ClassFaculty clsf);
	public List<ClassFaculty> ShowAll();
	boolean mapClassFaculty(String fname, String cname);
	Faculty getFaculty(String fname);
	Class getClass(String cname);

}*/
