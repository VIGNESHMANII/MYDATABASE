package com.StudentMarksManagementApp.controllers;

public class MarksController {

}
