package com.StudentMarksManagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMarksManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
