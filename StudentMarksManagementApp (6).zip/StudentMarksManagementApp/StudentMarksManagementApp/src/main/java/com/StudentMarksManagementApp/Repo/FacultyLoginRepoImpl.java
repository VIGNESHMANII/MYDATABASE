package com.StudentMarksManagementApp.Repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Entity.Student;

public class FacultyLoginRepoImpl implements FacultyLoginRepo {
	
	@Autowired
	JdbcTemplate jt;

	@Override
	public Faculty showFaculty(int facl) {
		// TODO Auto-generated method stub
		String str="Select * from FacultyInfo where email=? and password=?";
		Faculty fac=null;
		try {
			fac=(Faculty) jt.queryForObject(str, new Object[] {facl}, new BeanPropertyRowMapper(Faculty.class));
		}
		catch(Exception e) {
			fac=null;
		}
		return fac;
	}

	@Override
	public List<Faculty> searchFaculycr() {
		String str="Select email,password from FacultyInfo";
		List<Faculty> list1=jt.query(str, new BeanPropertyRowMapper(Faculty.class));
		return list1;
	}

	@Override
	public Faculty changePassword(String password) {
		// TODO Auto-generated method stub
		String str="update password set=? where email=? from FacultyInfo;";
		try {
			Faculty faccc=(Faculty) jt.queryForObject(str, new Object[] {password}, new BeanPropertyRowMapper(Faculty.class));
			return faccc;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

	/*@Override
	public List<Student> ShowStudent() {
		// TODO Auto-generated method stub
		String str="Select * from StudentReg as s where s.classId=?  inner join ClassFaculty as c on s.classId=c.classId inner join FacultyInfo as f on c.fid=f.fid"
		return null;
	}*/

}
