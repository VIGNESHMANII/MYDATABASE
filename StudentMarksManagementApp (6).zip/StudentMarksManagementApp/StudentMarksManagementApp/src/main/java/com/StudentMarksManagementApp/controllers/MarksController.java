package com.StudentMarksManagementApp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.StudentMarksManagementApp.Entity.Class;
import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Entity.Marks;
import com.StudentMarksManagementApp.Entity.Student;
import com.StudentMarksManagementApp.Repo.MarksRepoImpl;

@Controller
public class MarksController {
	
	@Autowired
	MarksRepoImpl mr;
	
	@GetMapping("marks")
	public String show(Model m) {
		
		List<Student> sAll=mr.showStd();
		m.addAttribute("sAll", sAll);
		System.out.println("show class list");
		List<Class> cAll=mr.showClass();
		m.addAttribute("cAll", cAll);
		return "AddMarks";
	}
	
	@GetMapping("smarks")
	public String ShowAll(Model m)
	{
		List<Marks> mlist=mr.ShowAll();
		m.addAttribute("mlist", mlist);
     	return "ShowMarks";
	}
	
	@PostMapping("marks")
	public String Addmarkss(@RequestParam String examtype,@RequestParam Integer science,@RequestParam Integer math,@RequestParam Integer computers,@RequestParam Integer total,@RequestParam Integer average,@RequestParam String grade,@RequestParam String rollno,@RequestParam Integer classId,@RequestParam String fid,Model m)
	{
		Marks mm=new Marks();
		mm.setExamtype(examtype);
		mm.setScience(science);
		mm.setMath(math);
		mm.setComputers(computers);
		mm.setTotal(total);
		mm.setAverage(average);
		mm.setGrade(grade);
		mm.setRollno(rollno);
		mm.setClassId(classId);
		mm.setFid(fid);
		String r=mr.AddMarks(mm);
		m.addAttribute("msg",r);
		
		List<Marks> mlist=mr.ShowAll();
		m.addAttribute("mlist", mlist);
     	return "AddMarks";
	}

}
