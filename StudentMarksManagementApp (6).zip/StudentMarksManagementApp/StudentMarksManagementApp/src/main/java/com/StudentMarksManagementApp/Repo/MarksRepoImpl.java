package com.StudentMarksManagementApp.Repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.StudentMarksManagementApp.Entity.Class;
import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Entity.Marks;
import com.StudentMarksManagementApp.Entity.Student;
@Component
public class MarksRepoImpl implements MarksRepo {

	@Autowired
	JdbcTemplate jt;
	
	@Override
	public String AddMarks(Marks marks) {
		// TODO Auto-generated method stub
		String str="Insert into marksInfo(examtype,science,math,computers,rollno,classId,fid) values(?,?,?,?,?,?,?)";
		int r= jt.update(str, new Object[] {marks.getExamtype(), marks.getScience(), marks.getMath(), marks.getComputers(), marks.getRollno(), marks.getClassId(), marks.getFid()});
		if(r>=1)
			return "Marks Added";
		else
			return "error";
	}

	@Override
	public List<Marks> ShowAll() {
		// TODO Auto-generated method stub
		String str="Select * from MarksInfo";
		List<Marks> listAll=jt.query(str, new BeanPropertyRowMapper(Marks.class));
		return listAll;
	}

	@Override
	public List<Class> showClass() {
		String str="SELECT * FROM ClassInfo";
		List<Class> cAll=jt.query(str, new BeanPropertyRowMapper(Class.class));
		return cAll;
	}

	@Override
	public List<Student> showStd() {
		// TODO Auto-generated method stub
		String str="Select * from StudentReg";
		List<Student> sAll=jt.query(str,new BeanPropertyRowMapper(Student.class));
		return sAll;
	}

}
