package com.StudentMarksManagementApp.Repo;



import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.StudentMarksManagementApp.Entity.ClassFaculty;
import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Entity.Class;


/*import com.StudentMarksApp.Entity.ClassFaculty;
import com.StudentMarksApp.Entity.Classes;
import com.StudentMarksApp.Entity.Faculty;
import com.StudentMarksApp.Entity.Student;*/



@Component
public class ClassFacultyRepoImpl implements ClassFacultyRepo {

@Autowired
JdbcTemplate jt;



@Override
public List<Faculty> showFaculty() {
// TODO Auto-generated method stub
String query="SELECT * FROM FacultyInfo";
List<Faculty> fAll=jt.query(query, new BeanPropertyRowMapper(Faculty.class));
return fAll;

}



@Override
public List<Class> showClass() {
// TODO Auto-generated method stub
String query="SELECT * FROM ClassInfo";
List<Class> cAll=jt.query(query, new BeanPropertyRowMapper(Class.class));
return cAll;
}

@Override
public String addClassFaculty(ClassFaculty cfo) {
// TODO Auto-generated method stub
int n=0;
int c=cfo.getClassId();
String f=cfo.getFid();
for(ClassFaculty cl:showClassFaculty()) {

if(c==cl.getClassId()) {
n++;
}
}
for(ClassFaculty cl:showClassFaculty()) {

if(cl.getFid().equals(f)) {
n++;
}
}


if(n>0) {
return "Already mapped!!";
}
else {

String sql="INSERT INTO ClassFaculty (classID,fid)"
+ " VALUES(?,?)";
int r=jt.update(sql,new Object[] {c,f});
if(r>=1)
return "ClassFaculty Details Added Succesfully";
else
return "Error occured...";
}



}



@Override
public List<ClassFaculty> showClassFaculty() {
// TODO Auto-generated method stub
String query="SELECT * FROM ClassFaculty";
List<ClassFaculty> cfAll=jt.query(query, new BeanPropertyRowMapper(ClassFaculty.class));
return cfAll;

}



}







/*package com.StudentMarksManagementApp.Repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.StudentMarksManagementApp.Entity.ClassFaculty;
import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Entity.Class;

@Component
public class ClassFacultyRepoImpl implements ClassFacultyRepo {

	@Autowired
	JdbcTemplate jt;
	
	@Override
	public boolean mapClassFaculty(String fname, String cname) {
		Class c= getClass(cname);
		Faculty f= getFaculty(fname);
		// TODO Auto-generated method stub
		String str="Insert into ClassFaculty(classId,fid) values(?,?)";
		try {
		int r=jt.update(str, new Object[] {c.getClassId(),f.getFid()});
		if(r>=1) {
			   return true;
		}else
				return false;
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		return false;
	}
	@Override
	public Faculty getFaculty(String fname) {
		// TODO Auto-generated method stub
		String str="Select * from FacultyInfo where factName=?;";
		try {
			Faculty faculty=(Faculty)jt.queryForObject(str, new Object[]{fname},new BeanPropertyRowMapper(Faculty.class));
			return faculty;
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return null;
	}
	@Override
	public Class getClass(String cname) {
		// TODO Auto-generated method stub
		String str="Select * from ClassInfo where className=?;";
		try {
			Class class1=(Class)jt.queryForObject(str, new Object[]{cname},new BeanPropertyRowMapper(Class.class));
			return class1;
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return null;
	}

	@Override
	public List<ClassFaculty> ShowAll() {
		// TODO Auto-generated method stub
		String str="Select * from ClassFaculty";
		List<ClassFaculty> listAll=jt.query(str, new BeanPropertyRowMapper(ClassFaculty.class));
		return listAll;
	}

	@Override
	public String AddClassFaculty(ClassFaculty clsf) {
		// TODO Auto-generated method stub
		return null;
	}
	

}*/
