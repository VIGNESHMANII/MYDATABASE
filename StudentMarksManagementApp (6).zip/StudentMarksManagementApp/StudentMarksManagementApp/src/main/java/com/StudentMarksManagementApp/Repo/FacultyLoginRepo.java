package com.StudentMarksManagementApp.Repo;

import java.util.List;

import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Entity.Student;

public interface FacultyLoginRepo {
	
	public Faculty showFaculty(int facl);
	public List<Faculty> searchFaculycr();
	//public List<Student> ShowStudent();
	public Faculty changePassword(String password);
	

}
