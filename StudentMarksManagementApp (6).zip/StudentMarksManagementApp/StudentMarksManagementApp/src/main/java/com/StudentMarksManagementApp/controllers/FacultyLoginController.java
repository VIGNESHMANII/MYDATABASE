package com.StudentMarksManagementApp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Repo.FacultyLoginRepoImpl;

@Controller
public class FacultyLoginController {

	//@Autowired
	//FacultyLoginRepoImpl flr;
	
	@GetMapping("fstd")
	public String fstd() {
		return "StudentsInfo";
	}
	@GetMapping("cpass")
	public String cpass()
	{
		return "ChangePassword";
	}
	/*@PostMapping("cpass")
	public String changepass(@RequestParam String password,Model m)
	{
		Faculty f=new Faculty();
		String s=f.getPassword();//opass and npass have to be used here.
		if(password==null) {
			System.out.println("Wrong Input!!!");
			return "ChangePassword";
		}
		else
		{
			flr.changePassword(password);
			System.out.println("Password Changeed Successfully!!");
			return "ChangePassword";
		}
	}*/
	
	/*Faculty fa=new Faculty();
	@GetMapping("fahome")
	public String fahome()
	{
		return "Facultywelcome";
	}
	
	@PostMapping("flogin")
	public String loginProcess(@RequestParam String username,@RequestParam String password,@RequestParam String select, Model m)
	{
		
		else {
			m.addAttribute("msg","Wrong username/password");
			return "Login";
		}
		return "Facultywelcome";
	}*/
}
