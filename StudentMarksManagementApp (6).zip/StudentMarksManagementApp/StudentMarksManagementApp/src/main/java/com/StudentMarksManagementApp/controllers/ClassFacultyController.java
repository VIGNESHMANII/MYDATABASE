package com.StudentMarksManagementApp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.StudentMarksManagementApp.Entity.ClassFaculty;
import com.StudentMarksManagementApp.Entity.Faculty;
import com.StudentMarksManagementApp.Entity.Class;
import com.StudentMarksManagementApp.Entity.Student;
import com.StudentMarksManagementApp.Repo.ClassFacultyRepo;

@Controller
public class ClassFacultyController {

@Autowired
ClassFacultyRepo cfr;

@GetMapping("addclassfaculty")
public String Show(Model m) {
System.out.println("class faculty mapping");
System.out.println("show faculty list");
List<Faculty> fAll=cfr.showFaculty();
m.addAttribute("fAll", fAll);
System.out.println("show class list");
List<Class> cAll=cfr.showClass();
m.addAttribute("cAll", cAll);
List<ClassFaculty> cfAll=cfr.showClassFaculty();
m.addAttribute("cfAll",cfAll);
return "FacultyClassMap";
}

@PostMapping("addclassfaculty")
public String AddNewStd(@RequestParam String txtcid,
@RequestParam String txtfid,
Model m)
{
Student st=new Student();
ClassFaculty cf=new ClassFaculty();
cf.setClassId(Integer.parseInt(txtcid));
cf.setFid(txtfid);
String res=cfr.addClassFaculty(cf);
m.addAttribute("msg", res);

return "FacultyClassMap";
}

/*@GetMapping("facultylist")
public String DisplayFaculty(Model m)
{
System.out.println("show faculty list");
List<Faculty> fAll=cfr.showFaculty();
m.addAttribute("fAll", fAll);
return "ClassFaculty";
}

@GetMapping("classlist")
public String showClass(Model m)
{
System.out.println("show class list");
List<Class> cAll=cfr.showClass();
m.addAttribute("cAll", cAll);
return "ClassFaculty";
}*/



}




/*@Controller
public class ClassFacultyController {
	
	@Autowired
	ClassFacultyRepo cfr;
	
	@GetMapping("Showall")
	public String AddClassFaculty(Model m)
	{
		return "FacultyClassMap";
	}
	
	@PostMapping("addclassfaculty")
	public String AddClassFacultyS(@RequestParam String fname, @RequestParam String cname, Model m) {
		boolean flag=cfr.mapClassFaculty(fname, cname);
		if(flag) {
		m.addAttribute("msg","Successfully mapped");
		List<ClassFaculty> listf=cfr.ShowAll();
		m.addAttribute("listf",listf);
		return "FacultyClassMap";
		}
		else {
			m.addAttribute("msg","Class Already Maped!!!");
			List<ClassFaculty> listf=cfr.ShowAll();
			m.addAttribute("listf",listf);
			return "FacultyClassMap";
		}
	}
	
	@GetMapping("addclassfaculty")
	public String ShowAll(Model m) {
		
		List<ClassFaculty> listf=cfr.ShowAll();
		m.addAttribute("listf",listf);
		return "FacultyClassMap";
	}

}*/
